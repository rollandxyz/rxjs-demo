import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LunaBlocksModule } from '../../projects/luna-blocks/src/lib/luna-blocks.module';
// import { LunaBlocksModule } from '../../dist/luna-blocks';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    LunaBlocksModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
