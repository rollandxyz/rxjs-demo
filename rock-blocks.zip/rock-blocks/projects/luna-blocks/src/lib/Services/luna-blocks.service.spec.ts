import { TestBed, inject } from '@angular/core/testing';

import { LunaBlocksService } from './luna-blocks.service';

describe('LunaBlocksService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LunaBlocksService]
    });
  });

  it('should be created', inject([LunaBlocksService], (service: LunaBlocksService) => {
    expect(service).toBeTruthy();
  }));
});
