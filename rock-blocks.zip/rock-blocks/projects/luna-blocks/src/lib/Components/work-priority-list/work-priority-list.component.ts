import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'luna-work-priority-list',
  templateUrl: './work-priority-list.component.html',
  styleUrls: ['./work-priority-list.component.css']
})
export class WorkPriorityListComponent implements OnInit {
  checked = false;
  indeterminate = false;
  labelPosition = 'after';
  disabled = false;

  constructor() { }

  ngOnInit() {
  }

}
