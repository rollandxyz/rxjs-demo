import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkPriorityListComponent } from './work-priority-list.component';

describe('WorkPriorityListComponent', () => {
  let component: WorkPriorityListComponent;
  let fixture: ComponentFixture<WorkPriorityListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkPriorityListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkPriorityListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
